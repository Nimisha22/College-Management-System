<?php
	$fullname = $_POST['fullname'];
	$SRN = $_POST['SRN'];
    $Department = $_POST['Department'];
	$Phone = $_POST['Phone'];
	$Password = $_POST['Password'];


	// Database connection
	$conn = new mysqli('localhost','root','','register');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into signup(fullname,SRN, Department, Phone, Password) values(?, ?, ?, ?, ?)");
		$stmt->bind_param("sssss", $fullname, $SRN, $Department, $Phone, $Password);
		$execval = $stmt->execute();
	
		if($execval) {
			header("Location:login.html");
		}

		
		$stmt->close();
		$conn->close();
	}
?>