<html>

    <head>
        <link rel="stylesheet" href="./Css/style.css">
    </head>

<title> Departments
</title>

<body>
    <br>
    
	
    <img src="./Images/logo.png" align=right height=50 width=220>
    <font size=15 color=red font-face="sans-sarif">Vishwakarma University</font>
    <br>
    <hr>


    <header>

        <div class="block">
            <button><a href="index.php">Home</a></button>
            <button><a href="dept.php">Departments</a></button>
            <button><a href="admission.html">Admissions</a></button>
            <button><a href="index.php">Contact Us</a></button>
            <div>

    </header>
    
    <h2> Departments & Courses offered</h2>

    <div class="row">
        <div class="column">
            <div class="card">
              <h3>ART AND<br> DESIGN</h3>
              <p>BA (ANIMATION & MULTIMEDIA)</p>
              <p>BA (FASHION & APPAREL DESIGN)</p>
              <p>BA (INTERIOR DESIGN)</p>
            </div>
          </div>

          <div class="column">
            <div class="card">
              <h3>SCIENCE & TECHNOLOGY</h3>
              <p>B.SC. (COMPUTER SCIENCE)</p>
              <p>B.TECH (COMPUTER)</p>
              <p>B.TECH (MECHANICAL)</p>
            </div>
          </div>

        <div class="column">
            <div class="card">
              <h3>COMMERCE & MANAGEMENT</h3>
              <p>BBA (INTERNATIONAL BUSINESS)</p>
              <p>BBA</p>
              <p>B.COM</p>
            </div>
          </div>

        <div class="column">
            <div class="card">
              <h3>LAW<br></h3><br>
              <p>BBA-LLB</p>
              <p>LLB</p>
              <p>LLM</p>
            </div>
          </div>

      </div>


    <hr>

    <body>

        <H2 align='Center'> Sample Time Table </H2>
        <br>
        <br>
        <TABLE align='Center' border='1' width=45%>
            <CAPTION align='Center'> <B>Time table for SEM-I of the Academic Year 2020-2021 </B> </CAPTION>

            <TR width=15%>

                <TD align='LEFT'> <B> Faculty : S & T </B></TD>
                <TD align='LEFT'> <B> School : SET </B> </TD>
                <TD align='LEFT'> <B> Department : Computer Engineering </B> </TD>
            </TR>
            <TR>
                <TD align='LEFT'> <B>Year: TY </B> </TD>
                <TD align='LEFT'> <B>Division : B </B> </TD>
                <TD align='LEFT'> <B>Period : June - Dec 2021 </B> </TD>
            </TR>
        </TABLE>
        <BR>
        <BR>
        <BR>
        <TABLE align=center border='1' width=75% height=60%>

            <TR align=Center>
                <TD> <B> Period </B> </TD>
                <TD> <B> I </B> </TD>
                <TD> <B> II </B></TD>
                <TD> <B> III </B> </TD>
                <TD> <B> IV </B></TD>
                <TD> <B> V </B></TD>
                <TD><B> VI </B></TD>
                <TD><B> VII </B></TD>
            </TR>
            <TR align=Center>
                <TD> <B>Time</B> </TD>
                <TD> 8:00-9:00 </TD>
                <TD> 9:00 -10:00 </TD>
                <TD> 10:15 - 11:15 </TD>
                <TD> 11:15 - 12.15 </TD>
                <TD> 1:00 - 2:00 </TD>
                <TD> 2:00 - 3:00 </TD>
                <TD> 3:15 - 4:15 </TD>
            </TR>
            <TR align=Center>
                <TD> <B> Monday </B> </TD>
                <TD> </TD>
                <TD> <B> PM (Th) - PJ </B></TD>
                <TD> <B> AS (Th) - KRP </B> </TD>
                <TD> <B> WT (Th) - SP </B> </TD>
                <TD colspan=2> <B> AS (Pr) - KRP</B> </TD>
                <TD> <B> CN (Th) - SS </B> </TD>
            </TR>

            <TR align=Center>
                <TD> <B> Tuesday </B> </TD>
                <TD> </TD>
                <TD> <B> PM (Th) - PJ </B></TD>
                <TD> <B> AS (Th) - KRP </B> </TD>
                <TD> <B> CN (Th) - SS </B> </TD>
                <TD colspan=2> <B> WT (Pr) - SP</B> </TD>
                <TD> <B> SP (Th) - RNP </B> </TD>
            </TR>

            <TR align=Center>
                <TD> <B> Wednesday </B> </TD>
                <TD> </TD>
                <TD> </TD>
                <TD> <B> OS (Th) - NZT </B> </TD>
                <TD> <B> SP (Th) - RNP </B> </TD>
                <TD colspan=2> <B> SP (Pr) - RNP </B> </TD>
                <TD> <B> AS (Th) - KRP </B> </TD>
            </TR>


            <TR align=Center>
                <TD> <B> Thursday </B> </TD>
                <TD> </TD>
                <TD> <B> DAA (Th) - AAD </B></TD>
                <TD> <B> SP (Th) - RNP </B> </TD>
                <TD> <B> OS (Th) - NZT </B> </TD>
                <TD colspan=2> <B> CN (Pr) - SS </B> </TD>
                <TD> </TD>
            </TR>


            <TR align=Center>
                <TD> <B> Friday </B> </TD>
                <TD> </TD>
                <TD> <B> DAA (Th) - AAD </B></TD>
                <TD> <B> CN (Th) - SS </B> </TD>
                <TD> <B> OS (Th) - NZT </B> </TD>
                <TD colspan=2> <B> OS (Pr) - NZT </B> </TD>
                <TD> <B> Mentor Mentee </B> </TD>
            </TR>


            <TR align=Center>
                <TD> <B> Saturday </B> </TD>
                <TD> </TD>
                <TD> <B> DAA (Th) - AAD </B></TD>
                <TD colspan=2> <B> App Dev </B> </TD>
                <TD> </TD>
                <TD> </TD>
                <TD> </TD>
            </TR>

            <CAPTION style='caption-side: bottom;' align=Center> <B> Short Break: 10:00 to 10:15 a.m. and 3:00 to 3:15
                    p.m.
                    <BR> Lunch Break: 12:15 to 1:00 p.m.<br>
                    Use (Th) for Theory and (Pr)- for Practical </B>
            </CAPTION>

        </TABLE>
        <?php include('common/footer.php') ?>
    </body>

</html>