<footer>
  <div class="footer-top">
    <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6 col-xs-12 segment-one md-mb-30 sm-mb-30">
            <h3>Vishwakarma University</h3>
            <p>This Project has been made by Nimisha Doshi.
              The pupose of this project is to learn web development.
              
            </p>
          </div>
          <div class="col-md-2 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Quick Links</h2>
            <ul>
              <li><a href="index.php">About VU</a></li>
              <li><a href="academics.php">Academics</a></li>
              <li><a href="admission.php">Apply for Admission</a></li>
            </ul>
          </div>
          <div class="col-md-4 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>Departments</h2>
            <ul>
              <li><a href="dept.php">Science & Technology</a></li>
              <li><a href="dept.php">Art & Design</a></li>
              <li><a href="dept.php">Commerce & Management</a></li>
              <li><a href="dept.php">Law</a></li>
              
            </ul>
          </div>  
          <div class="col-md-3 col-sm-6 col-xs-12 segment-two md-mb-30 sm-mb-30">
            <h2>CONTACT DETAILS</h2>
              <p>Address: Vishwakarma University
Survey No. 2, 3, 4 Laxmi Nagar,
Kondhwa Budruk, Pune - 411 048.
Maharashtra, India. </p>
              <p>Telephones: +91 9067002223</p>
              <p>E-mail: admissions@vupune.ac.in</p>
        </div>
      </div>
    </div>
    </div>
  <p class="footer-bottom-text">CopyRights © reserved by Nimisha Doshi</p>
</footer>