
	<?php include('common/header.php') ?>
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<head>
	<style>
    	header {
            background-image: url("back2.png");
			background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
            background-size: cover;
            height: 600px;
    	}
    	.uplinks {
    		margin: 2%;
    		text-align: center;
    		color: #48067e;
    	}
    	.uplinks:hover {
    		color: #e27115;
    		text-decoration: underline;
    	}
    	.typewrite {
    		text-decoration: none;
    	}
    	.width {
    		width: 10%;
    	}
    	.width2 {
    		width: 50%;
    	}
    	.image {
    		width: 100%;
    		height: 100%;
    		padding: 20px;
    		margin: 10px;
    	}
    	.text {
    		margin: 5%;
    		padding: 1%;
    	}
    	.image2 {
    		width: 100%;
    		height: 600px;
    		padding: 20px;
    		margin: 10px;
    	}
    	.footlink {
    		font-size: 50px;
    		display: inline-block;
  transition: transform .01s; 
  margin: 2%
}

.whats:hover{
	color: #25D366;
  transform: scale(2.5); 
}
.face:hover{
	color: #3b5998;
  transform: scale(2.5); 
}
.insta:hover{
	color: #E1306C;
  transform: scale(2.5); 
}
.tele:hover{
	color: #0088cc;
  transform: scale(2.5); 
}
.enve:hover{
	color: #D44638;
  transform: scale(2.5); 
}
.mobi:hover{
	color: #833AB4;
  transform: scale(2.5); 
}

        .design {
            padding-top: 200px;
            padding-left: 40px;
        }
        .height {
            height: 500px;
        }
    </style>
</head>
	<div class="home-div"></div>
	

		<div class = "w3-full" id = "codiac">
		<div class = "w3-half w3-card-4 w3-light-grey height">
			<p class = "w3-text-pink w3-xxlarge text">About Us</p>
			<p class = "w3-text-black w3-xlarge text">
                
                    Vishwakarma University is a natural offshoot of the Vishwakarma Group of Institutions’ educational
                    legacy spanning more than 35 years. The University focuses on academic excellence, positively impacting the student community and the society at
                    large. The learning model at Vishwakarma University is the combination of knowing, practicing, performing, and
                    reflecting.
                    
                           
            </p>

		</div>


		<div class = "w3-half height">
            <img src = "./Images/Board_Room.jpg" class = "image">
		</div>

	</div>



		<div class = "w3-full">

		<div class = "w3-half">
        <img src = "./Images/department.png" class = "image2 height">
		</div>

		<div class = "w3-half" id = "offer">
			<div class = "image2 w3-card-4 w3-light-grey height">
			<p class = "w3-text-pink w3-xxlarge text">Departments</p>
			<p class = "w3-text-black w3-xlarge text w3-text-white">8 Programmes in various disciplines are offered by 
                Vishwakarma University. <br> <br>
                Click <A href='dept.php'>here</A> to know more!</p>

		</div>
		</div>

		<div class = "w3-full">


			<div class = "w3-half">
			<div class = "image2 w3-card-4 w3-light-grey height">
			<p class = "w3-text-pink w3-xxlarge text">Admissions</p>
			<p class = "w3-text-black w3-xlarge text">Admissions are open for the Academic Year 2021 - 2022. <br>
                <br>Click <A href='admission.html'>here</A> to know more!</p>

		</div>
		</div>

		<div class = "w3-half">
			<img src = "./Images/vu.png" class = "height image2">
		</div>
		</div>

		<div class = "w3-full">

		<div class = "w3-half">
			<img src = "./Images/acheivement.jpg" class = "height image2">
		</div>

		<div class = "w3-half h">
			<div class = "image2 w3-card-4 w3-light-grey height">
			<p class = "w3-text-pink w3-xxlarge text">Placements</p>
            <p class = "w3-text-black w3-xlarge text">Dream Internships and Job Offers<br>
                <ul>
                    <h5>
                        <li>Nimisha Doshi - Amazon</li>
                        <li>Karan Jagtiani - Hackerrank</li>
                        <li>Siddhant Munot - Groww</li>
                </ul>
            </p>

		</div>
		</div>
		</div>

	<?php include('common/cards.php') ?>
	<?php include('common/footer.php') ?>
</body>
</html>

